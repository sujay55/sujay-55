package com.example.honeywellovation.stockticker;

import android.content.Context;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.graphics.Color;
import android.graphics.Typeface;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.AsyncTask;
import android.provider.Settings;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.CardView;
import android.text.SpannableString;
import android.text.SpannableStringBuilder;
import android.text.style.BackgroundColorSpan;
import android.text.style.ForegroundColorSpan;
import android.text.style.StyleSpan;
import android.view.View;
import android.view.WindowManager;
import android.view.inputmethod.InputMethodManager;
import android.widget.AutoCompleteTextView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;


public class MainActivity extends AppCompatActivity {

    AutoCompleteTextView autoCompleteTextView;
    LinearLayout stockLayout;
    List<TextView> textViews=new ArrayList<TextView>();
    List<CardView> cardViews=new ArrayList<CardView>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
        this.getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN);

        autoCompleteTextView=(AutoCompleteTextView)findViewById(R.id.stockSymbol);
        stockLayout=(LinearLayout)findViewById(R.id.stockLayout);
    }

    @Override
    protected void onResume() {
        super.onResume();
        try {
            //Check Internet connection
            ConnectivityManager connectivityManager = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
            NetworkInfo networkInfo = connectivityManager.getActiveNetworkInfo();
            if (!(networkInfo != null && networkInfo.isConnected())) {
                Toast.makeText(getApplicationContext(), "Please TURN ON Data Connection", Toast.LENGTH_SHORT).show();
                startActivity(new Intent(Settings.ACTION_WIFI_SETTINGS));
            } else {
                //get Stock quotes
                String url="http://download.finance.yahoo.com/d/quotes.csv?s=AAPL+GOOG+MSFT+YHOO+INTC+NVDA+SBUX+EBAY&f=nsac1p2kjd1t1";
                new Stock().execute(url);
            }
        }
        catch (Exception e){
            Toast.makeText(getApplicationContext(),e.toString(),Toast.LENGTH_LONG).show();
        }
    }


    public void clear(View view){
        autoCompleteTextView.setText("");

        stockLayout.removeAllViews();
        textViews.clear();
        cardViews.clear();
        InputMethodManager inputManager = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
        inputManager.hideSoftInputFromWindow(getCurrentFocus().getWindowToken(), 0);
        String url="http://download.finance.yahoo.com/d/quotes.csv?s=AAPL+GOOG+MSFT+YHOO+INTC+NVDA+SBUX+EBAY&f=nsac1p2kjd1t1";
        new Stock().execute(url);
    }

    public void searchStock(View view){
        try {
            stockLayout.removeAllViews();
            textViews.clear();
            cardViews.clear();
            InputMethodManager inputManager = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
            inputManager.hideSoftInputFromWindow(getCurrentFocus().getWindowToken(), 0);
            String stockSymbol=autoCompleteTextView.getText().toString();
            autoCompleteTextView.setText(stockSymbol+"+");
            String url="http://download.finance.yahoo.com/d/quotes.csv?s="+stockSymbol+"&f=nsac1p2kjd1t1";
            new Stock().execute(url);
        }
        catch (Exception e){
            Toast.makeText(getApplicationContext(),e.toString(),Toast.LENGTH_LONG).show();
        }
    }


    public class Stock extends AsyncTask<String, String, String> {

        @Override
        protected String doInBackground(String... params) {
            HttpURLConnection connection = null;
            BufferedReader reader = null;
            try {

                URL url = new URL(params[0]);
                connection = (HttpURLConnection) url.openConnection();
                connection.connect();
                InputStream stream = connection.getInputStream();
                reader = new BufferedReader(new InputStreamReader(stream));
                String line = "";
                StringBuffer buffer = new StringBuffer();
                while ((line = reader.readLine()) != null) {
                    buffer.append(line+",");
                }
                return buffer.toString();
            } catch (Exception e) {
                Toast.makeText(getApplicationContext(),"Error Fetching Stock Quotes",Toast.LENGTH_SHORT).show();
            } finally {
                if (connection != null) {
                    connection.disconnect();
                }
                try {
                    if (reader != null) {
                        reader.close();
                    }
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
            return null;
        }


        @Override
        protected void onPostExecute(String s) {
            try {
                super.onPostExecute(s);
                s = s.replaceAll("[\"]+", "");
                //s=s.replaceAll("[,]+"," | ");

                String[] sampleArray = s.split(",");
                SpannableStringBuilder builder = new SpannableStringBuilder();
                int arrayCount = sampleArray.length;

                for (int i = 0; i < arrayCount; i = i + 9) {
                    builder.clear();
                    String temp1 = "Name : " + sampleArray[i] + "\t\tSymbol :" + sampleArray[i + 1] + "\n\nPrice :" + sampleArray[i + 2] + "\t\tChange : ";
                    String temp2 = sampleArray[i + 3] + "(" + sampleArray[i + 4] + ")";
                    String temp3 = "\n\n" + "52 Week High : " + sampleArray[i + 5] + "\t\t" + "52 Week Low : " + sampleArray[i + 6] + "\n\n" + "Date : " + sampleArray[i + 7] + "\t\tTime :" + sampleArray[i + 8];

                    SpannableString spannable = new SpannableString(temp1);
                    spannable.setSpan(new ForegroundColorSpan(Color.BLACK), 0, temp1.length(), 0);

                    SpannableString spannable3 = new SpannableString(temp3);
                    spannable3.setSpan(new ForegroundColorSpan(Color.BLACK), 0, temp3.length(), 0);

                    //Object greySpan=new BackgroundColorSpan(Color.GRAY);
                    //spannable.setSpan(greySpan,0,temp1.length(),0);
                    builder.append(spannable);
                    if (temp2.contains("+")) {
                        SpannableString spannable1 = new SpannableString(temp2);
                        spannable1.setSpan(new ForegroundColorSpan(Color.rgb(0, 128, 0)), 0, temp2.length(), 0);
                        spannable1.setSpan(new StyleSpan(Typeface.BOLD), 0, temp2.length(), 0);
                        //spannable1.setSpan(greySpan,0,temp2.length(),0);
                        builder.append(spannable1);
                    } else {
                        SpannableString spannable1 = new SpannableString(temp2);
                        spannable1.setSpan(new ForegroundColorSpan(Color.RED), 0, temp2.length(), 0);
                        spannable1.setSpan(new StyleSpan(Typeface.BOLD), 0, temp2.length(), 0);
                        //spannable1.setSpan(greySpan,0,temp2.length(),0);
                        builder.append(spannable1);
                    }
                    builder.append(spannable3);
                    TextView stockDetails = new TextView(getApplicationContext());
                    stockDetails.setText(builder);
                    textViews.add(stockDetails);

                }

                for (int i = 0; i < textViews.size(); i++) {
                    CardView cardView = new CardView(getApplicationContext());
                    cardView.setCardBackgroundColor(Color.parseColor("#FFFFFFFF"));
                    cardView.setRadius(30);
                    cardView.setContentPadding(10, 10, 30, 10);
                    cardView.setMaxCardElevation(15);
                    cardView.setCardElevation(10);
                    cardView.setUseCompatPadding(true);
                    cardView.addView(textViews.get(i));
                    cardViews.add(cardView);
                }

                for (int i = 0; i < cardViews.size(); i++) {
                    stockLayout.addView(cardViews.get(i));
                }

            }
            catch (Exception e){
                Toast.makeText(getApplicationContext(),e.toString(),Toast.LENGTH_LONG).show();
            }
        }
    };


}
